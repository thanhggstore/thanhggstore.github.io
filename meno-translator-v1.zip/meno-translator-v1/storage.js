
const doubleClick = true;
const holdCommand = false;
const holdAlt = false;
const holdCtrl = false;
const autoAudio = false;
const autoLang = false;
const notify = true;
const showHints = true;
const notNew = true;
const remember = '';
const userid = '';
const avatar = '';
const sourceLanguage = 'en';
const targetLanguage = 'ru';
const currentTranslation = {};
const currentContext = '';
const currentContextTranslation = '';
const historyTranslations = [];
const pageText = '';
const pageTitle = '';
const knownLanguages = [navigator.language.slice(0, 2).toLowerCase()];
const lastAlert = '';
const fetching = false;
const isMac = false;
const learningLanguage = '';
const triggerTargetAlert = true;

checkStoredSettings = storedSettings => {
    if (!storedSettings.notNew) {
        chrome.storage.local.set({
            doubleClick,
            holdCommand,
            holdAlt,
            autoAudio,
            autoLang,
            notify,
            showHints,
            notNew,
            remember,
            userid,
            avatar,
            sourceLanguage,
            targetLanguage,
            currentTranslation,
            currentContext,
            currentContextTranslation,
            historyTranslations,
            pageText,
            pageTitle,
            knownLanguages,
            fetching,
            isMac,
            holdCtrl,
            learningLanguage,
            triggerTargetAlert
        });
    }
    
    let targetLanguageNew = navigator.language.slice(0, 2).toLowerCase()
    if (targetLanguageNew != targetLanguage) {
        chrome.storage.local.set({targetLanguage: targetLanguage})
    }
    chrome.storage.local.set({isMac: navigator.platform.indexOf('Mac') > -1})
}

const gettingStoredSettings = chrome.storage.local.get(null, checkStoredSettings);